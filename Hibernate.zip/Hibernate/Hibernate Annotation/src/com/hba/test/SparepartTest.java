package com.hba.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hba.entity.Sparepart;

public class SparepartTest {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionFactory= configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Sparepart sparepart = (Sparepart) session.get(Sparepart.class, 3011);
		System.out.println(sparepart);
	}

}

package com.hba.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "SPAREPART")
public class Sparepart {
	
	protected int sparepartNo;
	protected String sparepartName;
	protected String modelNo;
	protected Date purchaseDate;
	protected int price;

	@Id
	@Column(name="SPAREPART_NO")
	public int getSparepartNo() {
		return sparepartNo;
	}

	public void setSparepartNo(int sparepartNo) {
		this.sparepartNo = sparepartNo;
	}
	
	@Column(name="SPAREPART_NM")
	public String getSparepartName() {
		return sparepartName;
	}

	public void setSparepartName(String sparepartName) {
		this.sparepartName = sparepartName;
	}

	@Column(name="MODEL_NO")
	public String getModelNo() {
		return modelNo;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	@Column(name="PURCHASE_DT")
	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Column(name="PRICE")
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Sparepart [sparepartNo=" + sparepartNo + ", sparepartName=" + sparepartName + ", modelNo=" + modelNo
				+ ", purchaseDate=" + purchaseDate + ", price=" + price + "]";
	}
	
	
}

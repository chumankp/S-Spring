package com.hb.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.hb.entity.Sparepart;
import com.hb.inseter.ConnectionProviderInitier;

public class CustomConnTest {

	public static void main(String[] args) {
	StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure().
													addInitiator(new ConnectionProviderInitier()).build();
	
	MetadataSources metadataSource = new MetadataSources(serviceRegistry);
	Metadata metadata = metadataSource.getMetadataBuilder().build();
	SessionFactory sessionFactory = metadata.buildSessionFactory();
	Session session = sessionFactory.openSession();
	Sparepart sparepart = session.get(Sparepart.class, 3012);
	System.out.println(sparepart);
	}

}

package com.hb.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import org.hibernate.cfg.Environment;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.Configurable;
import org.hibernate.service.spi.Startable;
import org.hibernate.service.spi.Stoppable;

public class ConnectionProviderImpl implements ConnectionProvider, Startable, Stoppable, Configurable{
	
	protected String driverName;
	protected String dbUrl;
	protected String dbUserName;
	protected String dbPassword;
	Connection con = null;
	@Override
	public boolean isUnwrappableAs(Class arg0) {
		return true;
	}

	@Override
	public <T> T unwrap(Class<T> arg0) {
		return null;
	}

	@Override
	public void configure(Map configuration) {
		if(configuration.containsKey("hibernate.connection.driver_class")
				&& configuration.containsKey("hibernate.connection.url")
				&& configuration.containsKey("hibernate.connection.username")
				&& configuration.containsKey("hibernate.connection.password")) {
			driverName = (String) configuration.get(Environment.DRIVER);
			dbUrl = (String) configuration.get(Environment.URL);
			dbUserName = (String) configuration.get(Environment.USER); 
			dbPassword = (String) configuration.get(Environment.PASS);
		}
		else if(configuration.containsKey("connection.driver_class")
				&& configuration.containsKey("connection.url")
				&& configuration.containsKey("connection.username")
				&& configuration.containsKey("connection.password")){
			driverName = (String) configuration.get("connection.driver_class");
			dbUrl = (String) configuration.get("connection.url");
			dbUserName = (String) configuration.get("connection.username");
			dbPassword = (String) configuration.get("connection.password");
		}
	}

	@Override
	public void stop() {
		
	}

	@Override
	public void start() {
		
	}

	@Override
	public Connection getConnection() throws SQLException {
			try {
				System.out.println("connection get()");
				Class.forName(driverName);
				System.out.println(driverName);
				con = DriverManager.getConnection(dbUrl, dbUserName, dbPassword);			
				
			}catch(Exception e) {
				throw new SQLException(e);
			}
		return con;
	}
	
	@Override
	public void closeConnection(Connection arg0) throws SQLException {
		if(con.isClosed() ==  false) {
			con.close();
			System.out.println("connection closed()");
		}
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}

}

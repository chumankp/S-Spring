package com.hb.inseter;

import java.util.Map;

import org.hibernate.boot.registry.StandardServiceInitiator;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.ServiceRegistryImplementor;

import com.hb.provider.ConnectionProviderImpl;

public class ConnectionProviderInitier implements StandardServiceInitiator<ConnectionProvider>{

	@Override
	public Class<ConnectionProvider> getServiceInitiated() {
		System.out.println("getServiceInitiated()");
		
		return ConnectionProvider.class;
	}

	@Override
	public ConnectionProvider initiateService(Map arg0, ServiceRegistryImplementor arg1) {
		System.out.println("initiateService()");
		ConnectionProviderImpl connectionProviderImpl = new ConnectionProviderImpl();
		return connectionProviderImpl;
	}

}

package com.sub.entity;

import java.io.Serializable;

public class SubscriberPreferences implements Serializable{
	protected int subscriberNo;
	protected boolean dnd;
	protected boolean callWaiting;
	protected boolean callForwarding;
	protected Subscriber subscriber;
	
	public int getSubscriberNo() {
		return subscriberNo;
	}
	public void setSubscriberNo(int subscriberNo) {
		this.subscriberNo = subscriberNo;
	}
	public boolean isDnd() {
		return dnd;
	}
	public void setDnd(boolean dnd) {
		this.dnd = dnd;
	}
	public boolean isCallWaiting() {
		return callWaiting;
	}
	public void setCallWaiting(boolean callWaiting) {
		this.callWaiting = callWaiting;
	}
	public boolean isCallForwarding() {
		return callForwarding;
	}
	public void setCallForwarding(boolean callForwarding) {
		this.callForwarding = callForwarding;
	}
	public Subscriber getSubscriber() {
		return subscriber;
	}
	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (callForwarding ? 1231 : 1237);
		result = prime * result + (callWaiting ? 1231 : 1237);
		result = prime * result + (dnd ? 1231 : 1237);
		result = prime * result + subscriberNo;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubscriberPreferences other = (SubscriberPreferences) obj;
		if (callForwarding != other.callForwarding)
			return false;
		if (callWaiting != other.callWaiting)
			return false;
		if (dnd != other.dnd)
			return false;
		if (subscriberNo != other.subscriberNo)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "SubscriberPreferences [subscriberNo=" + subscriberNo + ", dnd=" + dnd + ", callWaiting=" + callWaiting
				+ ", callForwarding=" + callForwarding + ", subscriber=" + subscriber + "]";
	}
	
}

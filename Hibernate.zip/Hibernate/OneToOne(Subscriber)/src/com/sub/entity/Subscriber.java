package com.sub.entity;

import java.io.Serializable;
import java.util.Date;

public class Subscriber implements Serializable{
	protected int subscriberNo;
	protected String subscriberName;
	protected Date subscriptionDate;
	protected String mobileNo;
	protected String networkType;

	public int getSubscriberNo() {
		return subscriberNo;
	}

	public void setSubscriberNo(int subscriberNo) {
		this.subscriberNo = subscriberNo;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public Date getSubscriptionDate() {
		return subscriptionDate;
	}

	public void setSubscriptionDate(Date subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((networkType == null) ? 0 : networkType.hashCode());
		result = prime * result + ((subscriberName == null) ? 0 : subscriberName.hashCode());
		result = prime * result + subscriberNo;
		result = prime * result + ((subscriptionDate == null) ? 0 : subscriptionDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subscriber other = (Subscriber) obj;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (networkType == null) {
			if (other.networkType != null)
				return false;
		} else if (!networkType.equals(other.networkType))
			return false;
		if (subscriberName == null) {
			if (other.subscriberName != null)
				return false;
		} else if (!subscriberName.equals(other.subscriberName))
			return false;
		if (subscriberNo != other.subscriberNo)
			return false;
		if (subscriptionDate == null) {
			if (other.subscriptionDate != null)
				return false;
		} else if (!subscriptionDate.equals(other.subscriptionDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Subscriber [subscriberNo=" + subscriberNo + ", subscriberName=" + subscriberName + ", subscriptionDate="
				+ subscriptionDate + ", mobileNo=" + mobileNo + ", networkType=" + networkType + "]";
	}

}

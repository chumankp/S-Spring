package com.sub.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.sub.entity.Subscriber;
import com.sub.entity.SubscriberPreferences;
import com.sub.util.HibernateSessionFactory;

public class SubTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		Subscriber subscriber = null;
		SubscriberPreferences preferences = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
		}
		HibernateSessionFactory.closeSessionFactory();

	}

}

package com.tps.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.tps.entity.Account;
import com.tps.entity.CurrentAccount;
import com.tps.entity.SavingAccount;
import com.tps.util.HibernateSessionFactory;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Account account = null;
		CurrentAccount currentAccount = null;
		SavingAccount savingAccount = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			/*account = new Account();
			// account.setAccountNo(1)
			account.setAccountHolderName("Chuman");
			account.setOpenDate(new Date());
			account.setAccountBlance(5000);
			session.save(account);*/
			savingAccount = new com.tps.entity.SavingAccount();
			
			savingAccount.setAccountHolderName("dillip");
			savingAccount.setOpenDate(new Date());
			savingAccount.setHasCheckIssued("Yes");
			savingAccount.setMinimumBlance(1000);
			
			session.save(savingAccount);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				}
			}

		}
		HibernateSessionFactory.closeSessionFactory();
	}
}

package com.otmm.beans;

public class Branch {
	protected int branchNo;
}

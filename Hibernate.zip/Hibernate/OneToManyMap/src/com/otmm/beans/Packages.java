package com.otmm.beans;

public class Packages {

}

package com.dml.test;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dml.entity.Appointment;
import com.dml.util.HibernateSessionFactory;

public class IDGTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory =null;
		Transaction transaction = null;
		Session session =null;
		boolean flag = false;
		try {
			sessionFactory = HibernateSessionFactory.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Appointment appointment = new Appointment();
			/*Appointment appointment2 = (Appointment) session.get(Appointment.class, 1);
			appointment2.setDoctorName("chuman");*/
			appointment.setAppointmentNo(4);
			appointment.setAppDate(new Date());
			appointment.setDoctorName("deep");
			appointment.setPatientName("dusmant");
			appointment.setMobileNo("987654321");
			appointment.setEmailAddress("santosh@gmail.com");
			session.update(appointment);
			//session.update(appointment2);
			//transaction.commit();
			//System.out.println("appointment No: "+appointment.getAppointmentNo());
			flag = true;
		}catch(HibernateException he) {
			he.printStackTrace();
		}
		finally {
			if(transaction != null) {
				if (flag) {
					transaction.commit();
				}else {
					transaction.rollback();
				}
			}
			session.close();
		}
		HibernateSessionFactory.closeSessionFactory();
		sessionFactory.close();
	}

}

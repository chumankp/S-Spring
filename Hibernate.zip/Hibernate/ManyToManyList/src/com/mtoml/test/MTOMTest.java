package com.mtoml.test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mtoml.entity.Game;
import com.mtoml.entity.Player;
import com.mtoml.util.SessionFactoryRegistry;

public class MTOMTest {

	public static void main(String[] args) {
		Session session = null;
		Transaction txn = null;
		Player player = null;
		Game game = null;
		List<Player> players = null;
		boolean flag = false;
		try {
			session = SessionFactoryRegistry.getSessionFactory().getCurrentSession();
			txn = session.beginTransaction();
			/*players = new ArrayList<Player>();
			player = new Player();
			player.setPlayerName("Sachin");
			player.setAge(23);
			player.setGender("Male");
			session.save(player);
			players.add(player);

			player = new Player();
			player.setPlayerName("Sachin");
			player.setAge(23);
			player.setGender("Male");
			session.save(player);
			players.add(player);

			game = new Game();
			game.setDescription("OutDoor");
			game.setGameName("One Day");
			game.setPlayers(players);
			session.save(game);*/
			
			player = new Player();
			player.setPlayerName("Sachin");
			player.setAge(23);
			player.setGender("Male");
			//players.add(player);

			player = new Player();
			player.setPlayerName("Sachin");
			player.setAge(23);
			player.setGender("Male");
			//players.add(player);

			game = new Game();
			game.setDescription("OutDoor");
			game.setGameName("One Day");
			game.setPlayers(players);
			session.save(game);
			
			/*game=(Game)session.get(Game.class, 1);
			player = new Player();
			player.setPlayerName("Sachin");
			player.setAge(23);
			player.setGender("Male");
			game.getPlayers().add(player);
			session.save(game);*/
			/*
			game=(Game)session.get(Game.class, 1);
			session.delete(game);*/
			
			flag = true;
		} finally {
			if (txn != null) {
				if (flag) {
					txn.commit();
				} else {
					txn.rollback();
				}
			}
			SessionFactoryRegistry.closeSessionFactory();
		}
		
	}

}

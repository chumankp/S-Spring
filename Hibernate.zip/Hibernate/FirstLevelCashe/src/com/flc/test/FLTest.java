package com.flc.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.flc.entity.Product;
import com.flc.util.HibernateSessionFactory;

public class FLTest {

	public static void main(String[] args) {
		boolean flag = false;
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			Product product = new Product();
			/*Product product = (Product) session.get(Product.class, 1);
			System.out.println("get called()");
			System.out.println("product :- "+(product));
			Product product1 = (Product) session.get(Product.class, 1);
			System.out.println(product1);
			System.out.println("Product1 :- "+product1);
			System.out.println("Product == Product ??"+(product == product1));*/
			product.setProductNo(1);
			product.setProductName("micromax1");
			//session.save(product);
			//session.evict(product);
			product.setProductDesc("tv");
			product.setPrice(100);
			//session.flush();
			session.clear();
			session.save(product);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag == true) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
				session.close();
			}
			HibernateSessionFactory.closeSessionFactory();
		}
	}

}

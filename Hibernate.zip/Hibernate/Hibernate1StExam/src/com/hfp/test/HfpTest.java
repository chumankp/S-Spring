package com.hfp.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hfp.entity.Mechanic;

public class HfpTest {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Mechanic mechanic = (Mechanic) session.get(Mechanic.class, 5012);
		System.out.println(mechanic);
	}

}

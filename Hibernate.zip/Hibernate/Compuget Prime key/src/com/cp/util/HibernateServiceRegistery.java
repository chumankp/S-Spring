package com.cp.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class HibernateServiceRegistery {
	private static SessionFactory sessionfactory;

	public static synchronized SessionFactory getSessionFactory() {
		try {
			if (sessionfactory == null) {
				Configuration configuration = new Configuration().configure();
				StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
						.applySettings(configuration.getProperties()).build();
				sessionfactory = configuration.buildSessionFactory(registry);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sessionfactory;
	}

	public static void closeSessionFactory() {
		if (sessionfactory != null) {
			sessionfactory.close();
			sessionfactory = null;
		}
	}
}
package com.cp.entity;

import java.io.Serializable;

public class ProjAssigPK implements Serializable{
	private int assigNo;
	private int resourceNo;
	public int getAssigNo() {
		return assigNo;
	}
	public void setAssigNo(int assigNo) {
		this.assigNo = assigNo;
	}
	public int getResourceNo() {
		return resourceNo;
	}
	public void setResourceNo(int resourceNo) {
		this.resourceNo = resourceNo;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + assigNo;
		result = prime * result + resourceNo;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProjAssigPK other = (ProjAssigPK) obj;
		if (assigNo != other.assigNo)
			return false;
		if (resourceNo != other.resourceNo)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ProjAssigPK [assigNo=" + assigNo + ", resourceNo=" + resourceNo + "]";
	}
	
}

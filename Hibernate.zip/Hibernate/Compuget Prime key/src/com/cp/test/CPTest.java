package com.cp.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cp.entity.ProjAssigPK;
import com.cp.entity.ProjectAssignment;
import com.cp.util.HibernateServiceRegistery;

public class CPTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		boolean flag = false;
		/*try {
*/			sessionFactory = HibernateServiceRegistery.getSessionFactory();
			session = sessionFactory.openSession();
			/*for (int i = 0; i < 1; i++) {
				transaction = session.beginTransaction();
				ProjectAssignment assignment = new ProjectAssignment();
				assignment.setAssigNo(2);
				assignment.setResourceNo(2);
				assignment.setStartingDate(new Date());
				assignment.setEndDate(null);
				assignment.setName("dillip");
				assignment.setMobileNo("123456");
				assignment.setEmailAddress("hfg@hgj.com");
				session.save(assignment);
				transaction.commit();
				
				 * ProjectAssignment ass = (ProjectAssignment)
				 * session.get(ProjectAssignment.class, assignment);
				 
				flag = true;
			}*/
			/*ProjectAssignment id =new ProjectAssignment();
			id.setAssigNo(1);
			id.setResourceNo(1);*/
			ProjAssigPK id = new ProjAssigPK();
			id.setAssigNo(1);
			id.setResourceNo(1);
			ProjectAssignment assignment = (ProjectAssignment)session.get(ProjectAssignment.class, id);
			System.out.println(assignment);
		/*} finally {
			if (transaction != null) {

				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}

			}*/
			session.close();
			HibernateServiceRegistery.closeSessionFactory();
			sessionFactory.close();
		}
		
	}


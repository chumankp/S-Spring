package com.idg.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.idg.entity.Appointment;
import com.idg.util.HibernateSessionFactory;

public class IDGTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory =null;
		Transaction transaction = null;
		Session session =null;
		boolean flag = false;
		try {
			sessionFactory = HibernateSessionFactory.getSessionFactory();
			session = sessionFactory.openSession();
			
			for (int i = 0; i < 20; i++) {
			transaction = session.beginTransaction();
			Appointment appointment = new Appointment();
			//appointment.setAppointmentNo(3);
			appointment.setAppDate(new Date());
			appointment.setDoctorName("Dillip");
			appointment.setPatientName("santosh");
			appointment.setMobileNo("987654321");
			appointment.setEmailAddress("santosh@gmail.com");
			session.save(appointment);
			transaction.commit();
			System.out.println("appointment No: "+appointment.getAppointmentNo());
			}
			flag = true;
		}
		finally {
			if(transaction != null) {
				/*if (flag) {
					transaction.commit();
				}else {
					transaction.rollback();
				}*/
			}
			session.close();
		}
		HibernateSessionFactory.closeSessionFactory();
		sessionFactory.close();
	}

}

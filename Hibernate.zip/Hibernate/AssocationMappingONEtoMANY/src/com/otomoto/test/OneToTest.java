package com.otomoto.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otomoto.entity.Account;
import com.otomoto.entity.Organization;
import com.otomoto.util.HibernateSessionFactory;

public class OneToTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Account account = null;
		Organization organization = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			/*organization = new Organization();
			//organization.setOrgId(1);
			organization.setOrgName("SoftText");
			organization.setEstDate(new Date());
			organization.setDesc("soft");
			organization.setBussinessType("soft222");
			session.save(organization);
			
			account = new Account();
			account.setContactPerson("chuman");
			account.setOrganization(organization);
			session.save(account);*/
			account = (Account) session.get(Account.class, 2);
			System.out.println(account);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			HibernateSessionFactory.closeSessionFactory();
		}
		
		
		
	}

}

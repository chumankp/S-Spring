package com.hb.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;

import com.hb.registry.CustomConnectionImpl;

public class SSRTest {

	public static void main(String[] args) {
		Configuration configuration= new Configuration().configure();
		StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().
				applySettings(configuration.getProperties()).addService(ConnectionProvider.class, new CustomConnectionImpl()).build();
	SessionFactory factory=configuration.buildSessionFactory(ssr);
	Session session=factory.openSession();
	}

}

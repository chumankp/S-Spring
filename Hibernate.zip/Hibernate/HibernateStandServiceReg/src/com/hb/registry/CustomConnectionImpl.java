package com.hb.registry;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;

public class CustomConnectionImpl implements ConnectionProvider{

	@Override
	public boolean isUnwrappableAs(Class unwrapType) {
		return true;
	}

	@Override
	public <T> T unwrap(Class<T> unwrapType) {
		return null;
	}

	@Override
	public Connection getConnection() throws SQLException {
		Connection conn=null;
		try {
			System.out.println("connection()");
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/automobiles","root","chuman");
		}catch(Exception e) {
			throw new SQLException(e);
		}
		return conn;
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
		if(conn.isClosed()==false) {
			conn.close();
		}
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}

}

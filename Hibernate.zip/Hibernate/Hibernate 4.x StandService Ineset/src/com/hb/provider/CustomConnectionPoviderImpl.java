package com.hb.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.Startable;
import org.hibernate.service.spi.Stoppable;

public class CustomConnectionPoviderImpl implements ConnectionProvider, Startable, Stoppable,org.hibernate.service.spi.Configurable {

	private String driverName;
	private String url;
	private String userName;
	private String password;
	

	@Override
	public boolean isUnwrappableAs(Class unwrapType) {

		return false;
	}

	@Override
	public <T> T unwrap(Class<T> unwrapType) {

		return null;
	}

	

	@Override
	public void stop() {

	}

	@Override
	public void start() {

	}

	@Override
	public Connection getConnection() throws SQLException {
		Connection conn = null;
		try {
			System.out.println("Connection ()");
			System.out.println(driverName);
			Class.forName(driverName);
			conn=DriverManager.getConnection(url, userName, password);
		}
		catch(Exception e) {
			throw new SQLException(e);
		}
		return conn;
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
		if(conn.isClosed()==false) {
			conn.close();
			System.out.println("Connecton Close");
		}
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return true;
	}

	@Override
	public void configure(Map properties) {
		System.out.println("Configure()");
		driverName = (String) properties.get("hibernate.connection.driver_class");
		url = (String) properties.get("hibernate.connection.url");
		userName = (String) properties.get("hibernate.connection.username");
		password = (String) properties.get("hibernate.connection.password");
		
	}

}

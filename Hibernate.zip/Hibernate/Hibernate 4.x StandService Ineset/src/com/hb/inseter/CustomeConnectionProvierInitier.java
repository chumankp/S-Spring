package com.hb.inseter;

import java.util.Map;

import org.hibernate.boot.registry.StandardServiceInitiator;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.ServiceRegistryImplementor;

import com.hb.provider.CustomConnectionPoviderImpl;

public class CustomeConnectionProvierInitier implements StandardServiceInitiator<ConnectionProvider>{

	@Override
	public Class<ConnectionProvider> getServiceInitiated() {
		System.out.println("service povider()");
		return ConnectionProvider.class;
	}

	@Override
	public ConnectionProvider initiateService(Map configurationValues, ServiceRegistryImplementor registry) {
		CustomConnectionPoviderImpl conProvider= new CustomConnectionPoviderImpl();
		return conProvider;
	}

}

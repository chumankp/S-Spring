package com.mtom.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtom.entity.Candidate;
import com.mtom.entity.Job;
import com.mtom.utill.SessionFactoryRegistry;

public class MTMSTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		Job job = null;
		Candidate candidate = null;
		Boolean flag = false;
		Set<Candidate> candidates = null;
		//Set<Job> jobs = null;
		try {

			sessionFactory = SessionFactoryRegistry.getSessionFactory();
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();
			candidate = new Candidate();
			candidate.setCandidateName("Santosh");
			candidate.setAge(21);
			candidate.setExperiance(5);
			candidate.setQualification("MCA");
			session.save(candidate);
			candidates = new HashSet<Candidate>();
			//candidate.setJob(jobs);
			candidates.add(candidate);

			candidate = new Candidate();
			candidate.setCandidateName("Deep");
			candidate.setAge(22);
			candidate.setExperiance(3);
			candidate.setQualification("B.TECH");
			session.save(candidate);

			candidates.add(candidate);

			job = new Job();
			job.setTitle("java");
			job.setDesciption("SOFTWARE ENGINEER");
			job.setExperiance(3);
			job.setQualificaton("MCA");
			job.setCandidates(candidates);
			session.save(job);
			//jobs.add(job);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}

				SessionFactoryRegistry.closeSessionFactory();
			}

		}

	}

}

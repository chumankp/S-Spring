package com.mtom.entity;

import java.util.Set;

public class Candidate {
	protected int candidateNo;
	protected String candidateName;
	protected String qualification;
	protected int experiance;
	protected int age;
	protected Set<Job> jobs;
	public int getCandidateNo() {
		return candidateNo;
	}
	public void setCandidateNo(int candidateNo) {
		this.candidateNo = candidateNo;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getExperiance() {
		return experiance;
	}
	public void setExperiance(int experiance) {
		this.experiance = experiance;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Set<Job> getJobs() {
		return jobs;
	}
	public void setJobs(Set<Job> jobs) {
		this.jobs = jobs;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((candidateName == null) ? 0 : candidateName.hashCode());
		result = prime * result + candidateNo;
		result = prime * result + experiance;
		result = prime * result + ((qualification == null) ? 0 : qualification.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Candidate other = (Candidate) obj;
		if (age != other.age)
			return false;
		if (candidateName == null) {
			if (other.candidateName != null)
				return false;
		} else if (!candidateName.equals(other.candidateName))
			return false;
		if (candidateNo != other.candidateNo)
			return false;
		if (experiance != other.experiance)
			return false;
		if (qualification == null) {
			if (other.qualification != null)
				return false;
		} else if (!qualification.equals(other.qualification))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Candidate [candidateNo=" + candidateNo + ", candidateName=" + candidateName + ", qualification="
				+ qualification + ", experiance=" + experiance + ", age=" + age + ", jobs=" + jobs + "]";
	}
	
}

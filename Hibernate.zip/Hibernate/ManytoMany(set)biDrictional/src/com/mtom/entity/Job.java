package com.mtom.entity;

import java.util.Set;

public class Job {
	protected int jobNo;
	protected String title;
	protected String desciption;
	protected String qualificaton;
	protected int experiance;
	protected Set<Candidate> candidates;
	public int getJobNo() {
		return jobNo;
	}
	public void setJobNo(int jobNo) {
		this.jobNo = jobNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDesciption() {
		return desciption;
	}
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	public String getQualificaton() {
		return qualificaton;
	}
	public void setQualificaton(String qualificaton) {
		this.qualificaton = qualificaton;
	}
	public int getExperiance() {
		return experiance;
	}
	public void setExperiance(int experiance) {
		this.experiance = experiance;
	}
	public Set<Candidate> getCandidates() {
		return candidates;
	}
	public void setCandidates(Set<Candidate> candidates) {
		this.candidates = candidates;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((desciption == null) ? 0 : desciption.hashCode());
		result = prime * result + experiance;
		result = prime * result + jobNo;
		result = prime * result + ((qualificaton == null) ? 0 : qualificaton.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Job other = (Job) obj;
		if (desciption == null) {
			if (other.desciption != null)
				return false;
		} else if (!desciption.equals(other.desciption))
			return false;
		if (experiance != other.experiance)
			return false;
		if (jobNo != other.jobNo)
			return false;
		if (qualificaton == null) {
			if (other.qualificaton != null)
				return false;
		} else if (!qualificaton.equals(other.qualificaton))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Job [jobNo=" + jobNo + ", title=" + title + ", desciption=" + desciption + ", qualificaton="
				+ qualificaton + ", experiance=" + experiance + ", candidates=" + candidates + "]";
	}
	
}

package com.gvl.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class HibernateSessionFactory {
	public static SessionFactory sessionfactory;
	static {
		Configuration cfg = new Configuration();
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().
				applySettings(cfg.configure().getProperties()).build();
		sessionfactory = cfg.buildSessionFactory(ssr);
	}
	public static SessionFactory getSessionFactory() {
		return sessionfactory;
	}

	public static void closeSessionFactory() {
		if (sessionfactory != null) {
			sessionfactory.close();
		}
	}
}


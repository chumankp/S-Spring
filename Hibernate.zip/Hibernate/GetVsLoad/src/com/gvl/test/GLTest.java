package com.gvl.test;
                            
import org.hibernate.Session;

import com.gvl.entity.IMechanic;
import com.gvl.entity.Mechanic;
import com.gvl.util.HibernateSessionFactory;

public class GLTest {

	public static void main(String[] args) {
		IMechanic mechanic = null;
		Session session = null;
		try {
		session = HibernateSessionFactory.getSessionFactory().openSession();
		System.out.println("load is calling");
		mechanic = (IMechanic) session.load(Mechanic.class, 5011);
		System.out.println(mechanic);
		System.out.println("class "+mechanic.getClass().getName());
	}finally {
		if(session != null) {
		session.close();
		}
		HibernateSessionFactory.closeSessionFactory();
	}

}
}

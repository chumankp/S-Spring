package com.gvl.entity;

public interface IMechanic {
	public int getMechanic_No();

	public void setMechanic_No(int mechanic_No);

	public String getFirstName();

	public void setFirstName(String firstName);

	public String getLastName();

	public void setLastName(String lastName);

	public String getSpecialization();

	public void setSpecialization(String specialization);

	public int getExperience();

	public void setExperience(int experience);

	public int getContactNo();

	public void setContactNo(int contactNo);

	public String getEmailAddress();

	public void setEmailAddress(String emailAddress);
}

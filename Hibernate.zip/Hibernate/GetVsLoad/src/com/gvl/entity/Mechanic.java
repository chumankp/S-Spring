package com.gvl.entity;

final public class Mechanic implements IMechanic{
	protected int mechanic_No;
	protected String firstName;
	protected String lastName;
	protected String specialization;
	protected int experience;
	protected int contactNo;
	protected String emailAddress;
	
	@Override
	public int getMechanic_No() {
		return mechanic_No;
	}
	@Override
	public void setMechanic_No(int mechanic_No) {
		this.mechanic_No = mechanic_No;
	}
	@Override
	public String getFirstName() {
		return firstName;
	}
	@Override
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Override
	public String getLastName() {
		return lastName;
	}
	@Override
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String getSpecialization() {
		return specialization;
	}
	@Override
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	@Override
	public int getExperience() {
		return experience;
	}
	@Override
	public void setExperience(int experience) {
		this.experience = experience;
	}
	@Override
	public int getContactNo() {
		return contactNo;
	}
	@Override
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	@Override
	public String getEmailAddress() {
		return emailAddress;
	}
	@Override
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	@Override
	public String toString() {
		return "Mechanic [mechanic_No=" + mechanic_No + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", specialization=" + specialization + ", experience=" + experience + ", contactNo=" + contactNo
				+ ", emailAddress=" + emailAddress + "]";
	}
	
}
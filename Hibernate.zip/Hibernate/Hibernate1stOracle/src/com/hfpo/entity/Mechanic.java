package com.hfpo.entity;

public class Mechanic {
	protected int mechanic_No;
	protected String firstName;
	protected String lastName;
	protected String specialization;
	protected int experience;
	protected int contactNo;
	protected String emailAddress;
	public int getMechanic_No() {
		return mechanic_No;
	}
	public void setMechanic_No(int mechanic_No) {
		this.mechanic_No = mechanic_No;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@Override
	public String toString() {
		return "Mechanic [mechanic_No=" + mechanic_No + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", specialization=" + specialization + ", experience=" + experience + ", contactNo=" + contactNo
				+ ", emailAddress=" + emailAddress + "]";
	}
}

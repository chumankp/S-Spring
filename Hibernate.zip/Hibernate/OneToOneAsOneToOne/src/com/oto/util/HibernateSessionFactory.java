package com.oto.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class HibernateSessionFactory {
	private static SessionFactory sessionFactory;

	public static synchronized SessionFactory getSessionFactory() {
		try {
		if (sessionFactory == null) {
			Configuration cfg = new Configuration().configure();
			StandardServiceRegistry registry = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties())
					.build();
			sessionFactory = cfg.buildSessionFactory(registry);
		}
	}catch (Exception e) {
		e.printStackTrace();
		}
		return sessionFactory;
	}
	public static void closeSessionFactory() {
		if (sessionFactory != null) {
			sessionFactory.close();
			sessionFactory = null;
		}
	}
}
package com.oto.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.oto.entity.Candidate;
import com.oto.entity.Report;
import com.oto.util.HibernateSessionFactory;

public class OTOTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Candidate candidate = null;
		Report report = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			
			candidate = new Candidate();
			candidate.setCandidateName("Dusamant");
			candidate.setAppireDate(new Date());
			candidate.setContactNo("9876543210");
			candidate.setEmailAddress("dusa@gmail.com");
			candidate.setReport(report);
			session.save(candidate);
			
			report = new Report();
			report.setResult("selected");
			report.setRemark("Good");
			report.setComment("java full stack develpoer");
			report.setCandidate(candidate);
			session.save(report);
			
			/*candidate = (Candidate) session.get(Candidate.class, 1);
			System.out.println(candidate);*/
			
			/*report = (Report) session.get(Report.class, 1);
			System.out.println(report);*/
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
		}
		HibernateSessionFactory.closeSessionFactory();
	}

}

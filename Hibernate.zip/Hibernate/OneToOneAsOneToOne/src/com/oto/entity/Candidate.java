package com.oto.entity;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
@Entity
@Table(name="CANDIDATE")
public class Candidate implements Serializable {
	@Id
	@Column(name="CANDIDATE_NO")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	protected int candidateNo;
	@Column(name="CANDIDATE_NAME")
	protected String candidateName;
	@Column(name="APPER_DATE")
	protected Date appireDate;
	@Column(name="Contact_NO")
	protected String contactNo;
	@Column(name="EMIL_ADD")
	protected String emailAddress;
	@OneToOne
	@PrimaryKeyJoinColumn
	protected Report report;
	public int getCandidateNo() {
		return candidateNo;
	}
	public void setCandidateNo(int candidateNo) {
		this.candidateNo = candidateNo;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public Date getAppireDate() {
		return appireDate;
	}
	public void setAppireDate(Date appireDate) {
		this.appireDate = appireDate;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public Report getReport() {
		return report;
	}
	public void setReport(Report report) {
		this.report = report;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appireDate == null) ? 0 : appireDate.hashCode());
		result = prime * result + ((candidateName == null) ? 0 : candidateName.hashCode());
		result = prime * result + candidateNo;
		result = prime * result + ((contactNo == null) ? 0 : contactNo.hashCode());
		result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Candidate other = (Candidate) obj;
		if (appireDate == null) {
			if (other.appireDate != null)
				return false;
		} else if (!appireDate.equals(other.appireDate))
			return false;
		if (candidateName == null) {
			if (other.candidateName != null)
				return false;
		} else if (!candidateName.equals(other.candidateName))
			return false;
		if (candidateNo != other.candidateNo)
			return false;
		if (contactNo == null) {
			if (other.contactNo != null)
				return false;
		} else if (!contactNo.equals(other.contactNo))
			return false;
		if (emailAddress == null) {
			if (other.emailAddress != null)
				return false;
		} else if (!emailAddress.equals(other.emailAddress))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Candidate [candidateNo=" + candidateNo + ", candidateName=" + candidateName + ", appireDate="
				+ appireDate + ", contactNo=" + contactNo + ", emailAddress=" + emailAddress + ", report=" + report
				+ "]";
	}
	
}

package com.jpa.advisor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADVISOR")
public class Advisor {
	protected int AdvisorNo;
	protected String firstName;
	protected String lastName;
	protected String qualification;
	protected int experince;
	protected int contactNo;
	protected String emailAddress;
	@Id
	@Column(name ="ADVISOR_NO")
	public int getAdvisorNo() {
		return AdvisorNo;
	}
	public void setAdvisorNo(int advisorNo) {
		AdvisorNo = advisorNo;
	}
	@Column(name = "FIRST_NM")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Column(name = "LAST_NM")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Column(name = "QUALIFICATION")
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	@Column (name = "EXPERIENCE")
	public int getExperince() {
		return experince;
	}
	public void setExperince(int experince) {
		this.experince = experince;
	}
	@Column(name ="CONTACT_NO")
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	@Column(name = "EMAIL_ADDRESS")
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@Override
	public String toString() {
		return "Advisor [AdvisorNo=" + AdvisorNo + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", qualification=" + qualification + ", experince=" + experince + ", contactNo=" + contactNo
				+ ", emailAddress=" + emailAddress + "]";
	}
	
}

package com.jpa.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.jpa.advisor.Advisor;

public class JpaTest {
public static void main(String[] args) {
	boolean flag = false;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("advisor");
	EntityManager manager = factory.createEntityManager();
	manager.getTransaction().begin();
	Advisor advisor = new Advisor();
	try{
	advisor.setAdvisorNo(5);
	advisor.setFirstName("ck");
	advisor.setLastName("Panda");
	advisor.setQualification("mca");
	advisor.setExperince(5);
	advisor.setContactNo(12345678);
	advisor.setEmailAddress("hh@hh.com");
	
	manager.persist(advisor);
	//manager.getTransaction().commit();
	flag = true;
	}finally {
			if (flag) {
				manager.getTransaction().commit();
			}
			else {
				manager.getTransaction().rollback();
			}
			manager.close();
		}
		if (factory != null) {
			factory.close();
		}
	}
	
	
	/*Advisor advisor = manager.find(Advisor.class, 1);
	System.out.println(advisor);*/
}


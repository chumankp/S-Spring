package com.otm.test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.bytecode.internal.javassist.TransformingClassLoader;

import com.otm.entities.Project;
import com.otm.entities.Resources;
import com.otm.util.SessionFactoryRegistry;

public class OTMTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		Project project = null;
		Resources resource = null;
		Resources resource1 =null;
		Set<Resources> resources = null;
		boolean flag = false;
		try {
			factory = SessionFactoryRegistry.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			/*resources = new HashSet<Resources>();
			resource = new Resources();
			//resource.setResourcesNo(1);
			resource.setResourcesName("chuman");
			resource.setStartingDate(new Date());
			resource.setContactNo("123456789");
			resource.setEmailId("chuman@gmail.com");
			session.save(resource);
			resource1 =new Resources();
			resource1.setResourcesName("Deep");
			resource1.setStartingDate(new Date());
			resource1.setContactNo("132546");
			resource1.setEmailId("chuma@gm.com");
			session.save(resource1);
			resources.add(resource);
			resources.add(resource1);
			
			project = new Project();
			project.setProjectName("Banking");
			project.setDescProject("internate banking");
			project.setAssgingDate(new Date());
			project.setResources(resources);
			session.save(project);*/
			project = (Project) session.get(Project.class, 3);
			System.out.println(project);
			flag = true;
		}finally {
			if(transaction != null) {
				if (flag) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
			}
		}
		SessionFactoryRegistry.closeSessionFactory();
	}

}

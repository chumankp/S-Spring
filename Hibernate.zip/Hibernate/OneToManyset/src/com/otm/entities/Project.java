package com.otm.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

public class Project implements Serializable {
	protected int projectNo;
	protected String projectName;
	protected Date assgingDate;
	protected String descProject;
	protected Set<Resources> resources;

	public int getProjectNo() {
		return projectNo;
	}

	public void setProjectNo(int projectNo) {
		this.projectNo = projectNo;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Date getAssgingDate() {
		return assgingDate;
	}

	public void setAssgingDate(Date assgingDate) {
		this.assgingDate = assgingDate;
	}

	public String getDescProject() {
		return descProject;
	}

	public void setDescProject(String descProject) {
		this.descProject = descProject;
	}

	public Set<Resources> getResources() {
		return resources;
	}

	public void setResources(Set<Resources> resources) {
		this.resources = resources;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((assgingDate == null) ? 0 : assgingDate.hashCode());
		result = prime * result + ((descProject == null) ? 0 : descProject.hashCode());
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + projectNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (assgingDate == null) {
			if (other.assgingDate != null)
				return false;
		} else if (!assgingDate.equals(other.assgingDate))
			return false;
		if (descProject == null) {
			if (other.descProject != null)
				return false;
		} else if (!descProject.equals(other.descProject))
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		if (projectNo != other.projectNo)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Project [projectNo=" + projectNo + ", projectName=" + projectName + ", assgingDate=" + assgingDate
				+ ", descProject=" + descProject + ", resources=" + resources + "]";
	}

}

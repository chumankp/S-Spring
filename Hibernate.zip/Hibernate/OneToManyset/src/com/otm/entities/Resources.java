package com.otm.entities;

import java.io.Serializable;
import java.util.Date;

public class Resources implements Serializable {
	protected int resourcesNo;
	protected String resourcesName;
	protected Date startingDate;
	protected String contactNo;
	protected String emailId;

	public int getResourcesNo() {
		return resourcesNo;
	}

	public void setResourcesNo(int resourcesNo) {
		this.resourcesNo = resourcesNo;
	}

	public String getResourcesName() {
		return resourcesName;
	}

	public void setResourcesName(String resourcesName) {
		this.resourcesName = resourcesName;
	}

	public Date getStartingDate() {
		return startingDate;
	}

	public void setStartingDate(Date startingDate) {
		this.startingDate = startingDate;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contactNo == null) ? 0 : contactNo.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((resourcesName == null) ? 0 : resourcesName.hashCode());
		result = prime * result + resourcesNo;
		result = prime * result + ((startingDate == null) ? 0 : startingDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Resources other = (Resources) obj;
		if (contactNo == null) {
			if (other.contactNo != null)
				return false;
		} else if (!contactNo.equals(other.contactNo))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (resourcesName == null) {
			if (other.resourcesName != null)
				return false;
		} else if (!resourcesName.equals(other.resourcesName))
			return false;
		if (resourcesNo != other.resourcesNo)
			return false;
		if (startingDate == null) {
			if (other.startingDate != null)
				return false;
		} else if (!startingDate.equals(other.startingDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Resources [resourcesNo=" + resourcesNo + ", resourcesName=" + resourcesName + ", startingDate="
				+ startingDate + ", contactNo=" + contactNo + ", emailId=" + emailId + "]";
	}

}

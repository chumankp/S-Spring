package com.hb.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;

public class ConnectionProviderImpl implements ConnectionProvider {
	Connection con;
	@Override
	public boolean isUnwrappableAs(Class unwrapType) {
		return false;
	}

	@Override
	public <T> T unwrap(Class<T> unwrapType) {
		return null;
	}

	@Override
	public Connection getConnection() throws SQLException {
		try {
			System.out.println("getconnection()");
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/automobiles", "root", "chuman");
			System.out.println("connection created");
		}catch(Exception e) {
			throw new SQLException(e);
		}
		return con;
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
		if(con.isClosed() == false) {
			con.close();
		}
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return true;
	}

}

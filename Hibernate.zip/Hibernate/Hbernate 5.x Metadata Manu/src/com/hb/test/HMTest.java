package com.hb.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;

import com.hb.entity.Sparepart;
import com.hb.provider.ConnectionProviderImpl;

public class HMTest {

	public static void main(String[] args) {
		StandardServiceRegistry ssReg = new StandardServiceRegistryBuilder().
				addService(ConnectionProvider.class, new ConnectionProviderImpl()).configure().build();
		MetadataSources metadataSource = new MetadataSources(ssReg);
		Metadata source = metadataSource.buildMetadata();
		SessionFactory factory = source.buildSessionFactory();
		Session session = factory.openSession();
		Sparepart sparepart = session.get(Sparepart.class, 3011);
		System.out.println(sparepart);
	}

}

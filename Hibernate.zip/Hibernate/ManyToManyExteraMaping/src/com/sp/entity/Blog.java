package com.sp.entity;

import java.io.Serializable;
import java.util.Set;

public class Blog implements Serializable{
	protected int blogNo;
	protected String titleBlog;
	protected String description;
	protected SysUser sysUser;
	protected Set<UserBlog> userBlogs;
	public int getBlogNo() {
		return blogNo;
	}
	public void setBlogNo(int blogNo) {
		this.blogNo = blogNo;
	}
	public String getTitleBlog() {
		return titleBlog;
	}
	public void setTitleBlog(String titleBlog) {
		this.titleBlog = titleBlog;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public SysUser getSysUser() {
		return sysUser;
	}
	public void setSysUser(SysUser sysUser) {
		this.sysUser = sysUser;
	}
	public Set<UserBlog> getUserBlogs() {
		return userBlogs;
	}
	public void setUserBlogs(Set<UserBlog> userBlogs) {
		this.userBlogs = userBlogs;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + blogNo;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((titleBlog == null) ? 0 : titleBlog.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Blog other = (Blog) obj;
		if (blogNo != other.blogNo)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (titleBlog == null) {
			if (other.titleBlog != null)
				return false;
		} else if (!titleBlog.equals(other.titleBlog))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Blog [blogNo=" + blogNo + ", titleBlog=" + titleBlog + ", description=" + description + ", sysUser="
				+ sysUser + ", userBlogs=" + userBlogs + "]";
	}
	
}

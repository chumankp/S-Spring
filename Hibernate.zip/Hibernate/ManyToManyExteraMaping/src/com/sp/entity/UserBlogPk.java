package com.sp.entity;

import java.io.Serializable;

public class UserBlogPk implements Serializable{
	protected Blog blog;
	protected SysUser sysUser;
	public Blog getBlog() {
		return blog;
	}
	public void setBlog(Blog blog) {
		this.blog = blog;
	}
	public SysUser getSysUser() {
		return sysUser;
	}
	public void setSysUser(SysUser sysUser) {
		this.sysUser = sysUser;
	}
	
}

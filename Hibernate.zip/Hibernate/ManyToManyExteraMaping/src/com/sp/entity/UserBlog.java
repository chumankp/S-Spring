package com.sp.entity;

import java.io.Serializable;

public class UserBlog implements Serializable{
	protected UserBlogPk blogPk;
	protected String Rating;
	protected String commite;
	public UserBlogPk getBlogPk() {
		return blogPk;
	}
	public void setBlogPk(UserBlogPk blogPk) {
		this.blogPk = blogPk;
	}
	public String getRating() {
		return Rating;
	}
	public void setRating(String rating) {
		Rating = rating;
	}
	public String getCommite() {
		return commite;
	}
	public void setCommite(String commite) {
		this.commite = commite;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Rating == null) ? 0 : Rating.hashCode());
		result = prime * result + ((commite == null) ? 0 : commite.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBlog other = (UserBlog) obj;
		if (Rating == null) {
			if (other.Rating != null)
				return false;
		} else if (!Rating.equals(other.Rating))
			return false;
		if (commite == null) {
			if (other.commite != null)
				return false;
		} else if (!commite.equals(other.commite))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "UserBlog [blogPk=" + blogPk + ", Rating=" + Rating + ", commite=" + commite + "]";
	}
	
	
	
}

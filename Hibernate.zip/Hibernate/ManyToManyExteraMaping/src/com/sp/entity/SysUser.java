package com.sp.entity;

import java.io.Serializable;
import java.util.Set;

public class SysUser implements Serializable{
	protected int user_Id;
	protected String user_Name;
	protected String mailId;
	protected Set<Blog> blogs;
	protected Set<UserBlog> userBlogs;
	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	public String getUser_Name() {
		return user_Name;
	}
	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public Set<Blog> getBlogs() {
		return blogs;
	}
	public void setBlogs(Set<Blog> blogs) {
		this.blogs = blogs;
	}
	public Set<UserBlog> getUserBlogs() {
		return userBlogs;
	}
	public void setUserBlogs(Set<UserBlog> userBlogs) {
		this.userBlogs = userBlogs;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mailId == null) ? 0 : mailId.hashCode());
		result = prime * result + user_Id;
		result = prime * result + ((user_Name == null) ? 0 : user_Name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SysUser other = (SysUser) obj;
		if (mailId == null) {
			if (other.mailId != null)
				return false;
		} else if (!mailId.equals(other.mailId))
			return false;
		if (user_Id != other.user_Id)
			return false;
		if (user_Name == null) {
			if (other.user_Name != null)
				return false;
		} else if (!user_Name.equals(other.user_Name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "SysUser [user_Id=" + user_Id + ", user_Name=" + user_Name + ", mailId=" + mailId + ", blogs=" + blogs
				+ ", userBlogs=" + userBlogs + "]";
	}
	
}

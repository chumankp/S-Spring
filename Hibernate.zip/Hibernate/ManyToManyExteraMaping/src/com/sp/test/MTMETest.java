package com.sp.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sp.entity.Blog;
import com.sp.entity.SysUser;
import com.sp.entity.UserBlog;
import com.sp.entity.UserBlogPk;
import com.sp.util.SessionFactoryRegistry;

public class MTMETest {
public static void main(String[] args) {
	Session session = null;
	Transaction txn = null;
	Blog blog = null;
	SysUser systemUser = null;
	UserBlog blogUserRating = null;
	UserBlogPk pk=null;
	boolean flag = false;
	Set<UserBlog> blogRatings = null;
	Set<Blog> blogs = null;
	try {
		session = SessionFactoryRegistry.getSessionFactory().getCurrentSession();
		txn = session.beginTransaction();
		blogRatings = new HashSet<UserBlog>();
		blogs = new HashSet<Blog>();

		blog = new Blog();
		blog.setDescription("HashMap");
		blog.setTitleBlog("John");
		blogs.add(blog);

		systemUser = new SysUser();
		systemUser.setUser_Name("Sanju");
		systemUser.setMailId("sanju@gmail.com");
		systemUser.setBlogs(blogs);

		blog.setSysUser(systemUser);
		session.save(blog);

		systemUser = new SysUser();
		systemUser.setUser_Name("Biku");
		systemUser.setMailId("biku@gmail.com");
		
		pk=new UserBlogPk();
		pk.setBlog(blog);
		pk.setSysUser(systemUser);

		blogUserRating = new UserBlog();
		blogUserRating.setBlogPk(pk);
		blogUserRating.setCommite("nice blog");
		blogUserRating.setRating("5");
		blogRatings.add(blogUserRating);

		systemUser.setUserBlogs(blogRatings);
		session.save(systemUser);
		
		/*blog=(Blog) session.get(Blog.class,1);
		System.out.println(blog.getBlogUserRating());*/
		
		/*systemUser = (SysUser) session.get(SysUser.class, 1);
		System.out.println(systemUser.getUserBlogs());*/
		
		
		
		flag = true;
	} finally {
		if (txn != null) {
			if (flag) {
				txn.commit();
			} else {
				txn.rollback();
			}
		}
		SessionFactoryRegistry.closeSessionFactory();
	}
}

}


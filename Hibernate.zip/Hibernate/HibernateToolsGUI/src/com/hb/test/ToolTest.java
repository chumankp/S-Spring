package com.hb.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import com.hb.entity.Mechanic;

public class ToolTest {

	public static void main(String[] args) {
		Configuration conf = new Configuration().configure();
		/*SchemaExport se = new SchemaExport(conf);
		se.create(true, true);*/
		SessionFactory sf= conf.buildSessionFactory();
		Session sw = sf.openSession();
	}

}

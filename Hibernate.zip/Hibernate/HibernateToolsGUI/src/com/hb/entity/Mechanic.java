package com.hb.entity;

public class Mechanic implements java.io.Serializable {

	private int mechanicNo;
	private String firstNm;
	private String lastNm;
	private String specialization;
	private Integer experience;
	private Integer contactNo;
	private String emailAddress;

	public Mechanic() {
	}

	public Mechanic(int mechanicNo) {
		this.mechanicNo = mechanicNo;
	}

	public Mechanic(int mechanicNo, String firstNm, String lastNm, String specialization, Integer experience,
			Integer contactNo, String emailAddress) {
		this.mechanicNo = mechanicNo;
		this.firstNm = firstNm;
		this.lastNm = lastNm;
		this.specialization = specialization;
		this.experience = experience;
		this.contactNo = contactNo;
		this.emailAddress = emailAddress;
	}

	public int getMechanicNo() {
		return this.mechanicNo;
	}

	public void setMechanicNo(int mechanicNo) {
		this.mechanicNo = mechanicNo;
	}

	public String getFirstNm() {
		return this.firstNm;
	}

	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}

	public String getLastNm() {
		return this.lastNm;
	}

	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}

	public String getSpecialization() {
		return this.specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public Integer getExperience() {
		return this.experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public Integer getContactNo() {
		return this.contactNo;
	}

	public void setContactNo(Integer contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

}

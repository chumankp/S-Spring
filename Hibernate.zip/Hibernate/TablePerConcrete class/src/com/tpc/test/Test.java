package com.tpc.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.tpc.entity.Account;
import com.tpc.entity.CurrentAccount;
import com.tpc.entity.SavingAccount;
import com.tpc.util.HibernateSessionFactory;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Account account = null;
		CurrentAccount currentAccount = null;
		SavingAccount savingAccount = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			/*account = new Account();
			account.setAccountNo(1);
			account.setAccountHolderName("Chuman");
			account.setOpenDate(new Date());
			account.setAccountBlance(5000);
			session.save(account);*/
			/*savingAccount = new SavingAccount();
			savingAccount.setAccountHolderName("dillip");
			savingAccount.setHasCheckIssued("Yes");
			savingAccount.setMinimumBlance(1000);
			session.save(savingAccount);*/
			
			/*currentAccount = new CurrentAccount();
			currentAccount.setAccountNo(1);
			currentAccount.setAccountBlance(1000.0);
			currentAccount.setAccountHolderName("Chuman");
			currentAccount.setAnnumalFee(100);
			currentAccount.setOpenDate(new Date());
			currentAccount.setOverDrftLimit(2000);
			session.save(currentAccount);*/
			//currentAccount = (CurrentAccount)session.get(CurrentAccount.class, 3);
			flag = true;
			account = (Account)session.get(Account.class, 2);
			System.out.println(account);
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				}
			}

		}
		HibernateSessionFactory.closeSessionFactory();
	}
}

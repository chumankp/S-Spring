package com.tpc.entity;

public class SavingAccount extends Account{
	protected int withDrawLimit;
	protected String hasCheckIssued;
	protected int minimumBlance;

	public int getWithDrawLimit() {
		return withDrawLimit;
	}

	public void setWithDrawLimit(int withDrawLimit) {
		this.withDrawLimit = withDrawLimit;
	}

	public String getHasCheckIssued() {
		return hasCheckIssued;
	}

	public void setHasCheckIssued(String hasCheckIssued) {
		this.hasCheckIssued = hasCheckIssued;
	}

	public int getMinimumBlance() {
		return minimumBlance;
	}

	public void setMinimumBlance(int minimumBlance) {
		this.minimumBlance = minimumBlance;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hasCheckIssued == null) ? 0 : hasCheckIssued.hashCode());
		result = prime * result + minimumBlance;
		result = prime * result + withDrawLimit;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SavingAccount other = (SavingAccount) obj;
		if (hasCheckIssued == null) {
			if (other.hasCheckIssued != null)
				return false;
		} else if (!hasCheckIssued.equals(other.hasCheckIssued))
			return false;
		if (minimumBlance != other.minimumBlance)
			return false;
		if (withDrawLimit != other.withDrawLimit)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SavingAccount [withDrawLimit=" + withDrawLimit + ", hasCheckIssued=" + hasCheckIssued
				+ ", minimumBlance=" + minimumBlance + "]";
	}

}

package com.tpc.entity;

public class CurrentAccount extends Account {
	protected int overDrftLimit;
	protected int annumalFee;

	public int getOverDrftLimit() {
		return overDrftLimit;
	}

	public void setOverDrftLimit(int overDrftLimit) {
		this.overDrftLimit = overDrftLimit;
	}

	public int getAnnumalFee() {
		return annumalFee;
	}

	public void setAnnumalFee(int annumalFee) {
		this.annumalFee = annumalFee;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + annumalFee;
		result = prime * result + overDrftLimit;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CurrentAccount other = (CurrentAccount) obj;
		if (annumalFee != other.annumalFee)
			return false;
		if (overDrftLimit != other.overDrftLimit)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CurrentAccount [overDrftLimit=" + overDrftLimit + ", annumalFee=" + annumalFee + "]";
	}

}

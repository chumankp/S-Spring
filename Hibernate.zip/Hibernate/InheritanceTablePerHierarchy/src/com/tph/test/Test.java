package com.tph.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.tph.entity.Account;
import com.tph.entity.CurrentAccount;
import com.tph.entity.SavingAccount;
import com.tph.util.HibernateSessionFactory;

public class Test {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Account account = null;
		CurrentAccount currentAccount = null;
		SavingAccount savingAccount = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			account = new Account();
			// account.setAccountNo(1)
			/*account.setAccountHolderName("Chuman");
			account.setOpenDate(new Date());
			account.setAccountBlance(5000);
			session.save(account);*/
			/*savingAccount = new SavingAccount();
			savingAccount.setAccountHolderName("dillip");
			savingAccount.setHasCheckIssued("Yes");
			savingAccount.setMinimumBlance(1000);
			session.save(savingAccount);*/
			
			currentAccount = new CurrentAccount();
			currentAccount.setAccountHolderName("Dillip");
			currentAccount.setAccountBlance(1220.0);
			currentAccount.setAnnumalFee(1000);
			session.save(currentAccount);
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				}
			}

		}
		HibernateSessionFactory.closeSessionFactory();
	}
}

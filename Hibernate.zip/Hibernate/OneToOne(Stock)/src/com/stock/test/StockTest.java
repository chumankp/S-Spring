package com.stock.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.stock.entity.Stock;
import com.stock.entity.StockDetails;
import com.stock.util.HibernateSessionFactory;

public class StockTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		Stock stock = null;
		StockDetails details = null;
		boolean flag = false;
		try {
			factory = HibernateSessionFactory.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			
			/*stock = new Stock();
			stock.setStockCode("tcs");
			stock.setStockName("TATA");
			session.save(stock);
			
			details = new StockDetails();
			details.setCompanyName("TCS INDIA");
			details.setCompanyDesc("Software");
			details.setListingDate(new Date());
			details.setRemark("GOOD");
			details.setStock(stock);
			session.save(details);*/
			
			details = (StockDetails) session.get(StockDetails.class, 2);
			System.out.println(details);
			
			flag = true;
		}finally {
			if(transaction != null) {
				if (flag) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
			}
		HibernateSessionFactory.closeSessionFactory();
		}
	}

}

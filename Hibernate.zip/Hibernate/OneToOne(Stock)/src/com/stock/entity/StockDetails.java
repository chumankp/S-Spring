package com.stock.entity;

import java.io.Serializable;
import java.util.Date;

public class StockDetails implements Serializable {
	protected int stockId;
	protected String companyName;
	protected String companyDesc;
	protected String remark;
	protected Date listingDate;
	protected Stock stock;

	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyDesc() {
		return companyDesc;
	}

	public void setCompanyDesc(String companyDesc) {
		this.companyDesc = companyDesc;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getListingDate() {
		return listingDate;
	}

	public void setListingDate(Date listingDate) {
		this.listingDate = listingDate;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((companyDesc == null) ? 0 : companyDesc.hashCode());
		result = prime * result + ((companyName == null) ? 0 : companyName.hashCode());
		result = prime * result + ((listingDate == null) ? 0 : listingDate.hashCode());
		result = prime * result + ((remark == null) ? 0 : remark.hashCode());
		result = prime * result + stockId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StockDetails other = (StockDetails) obj;
		if (companyDesc == null) {
			if (other.companyDesc != null)
				return false;
		} else if (!companyDesc.equals(other.companyDesc))
			return false;
		if (companyName == null) {
			if (other.companyName != null)
				return false;
		} else if (!companyName.equals(other.companyName))
			return false;
		if (listingDate == null) {
			if (other.listingDate != null)
				return false;
		} else if (!listingDate.equals(other.listingDate))
			return false;
		if (remark == null) {
			if (other.remark != null)
				return false;
		} else if (!remark.equals(other.remark))
			return false;
		if (stockId != other.stockId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StockDetails [stockId=" + stockId + ", companyName=" + companyName + ", companyDesc=" + companyDesc
				+ ", remark=" + remark + ", listingDate=" + listingDate + ", stock=" + stock + "]";
	}

}

package com.oto.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.oto.entity.Account;
import com.oto.entity.Organization;
import com.oto.util.SessionFactoryRegistry;



public class OneToTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Transaction transaction = null;
		Session session = null;
		Account account = null;
		Organization organization = null;
		boolean flag = false;
		try {
			factory = SessionFactoryRegistry.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			/*organization = new Organization();
			//organization.setOrgId(1);
			organization.setOrgName("SoftText");
			organization.setEstDate(new Date());
			organization.setDesc("soft");
			organization.setBussinessType("soft222");
			session.save(organization);
			
			account = new Account();
			account.setContactPerson("chuman");
			account.setOrganization(organization);
			session.save(account);*/
			/*account = (Account) session.get(Account.class, 1);
			System.out.println(account);*/
			organization =(Organization) session.get(Organization.class, 1);
			System.out.println(organization.getAccount());
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			SessionFactoryRegistry.closeSessionFactory();
		}
		
		
		
	}

}

package com.oto.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

public class Organization implements Serializable {
	protected int orgId;
	protected String orgName;
	protected String desc;
	protected Date estDate;
	protected String bussinessType;
	protected Set<Account> account;
	public int getOrgId() {
		return orgId;
	}
	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Date getEstDate() {
		return estDate;
	}
	public void setEstDate(Date estDate) {
		this.estDate = estDate;
	}
	public String getBussinessType() {
		return bussinessType;
	}
	public void setBussinessType(String bussinessType) {
		this.bussinessType = bussinessType;
	}
	public Set<Account> getAccount() {
		return account;
	}
	public void setAccount(Set<Account> account) {
		this.account = account;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bussinessType == null) ? 0 : bussinessType.hashCode());
		result = prime * result + ((desc == null) ? 0 : desc.hashCode());
		result = prime * result + ((estDate == null) ? 0 : estDate.hashCode());
		result = prime * result + orgId;
		result = prime * result + ((orgName == null) ? 0 : orgName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Organization other = (Organization) obj;
		if (bussinessType == null) {
			if (other.bussinessType != null)
				return false;
		} else if (!bussinessType.equals(other.bussinessType))
			return false;
		if (desc == null) {
			if (other.desc != null)
				return false;
		} else if (!desc.equals(other.desc))
			return false;
		if (estDate == null) {
			if (other.estDate != null)
				return false;
		} else if (!estDate.equals(other.estDate))
			return false;
		if (orgId != other.orgId)
			return false;
		if (orgName == null) {
			if (other.orgName != null)
				return false;
		} else if (!orgName.equals(other.orgName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Organization [orgId=" + orgId + ", orgName=" + orgName + ", desc=" + desc + ", estDate=" + estDate
				+ ", bussinessType=" + bussinessType + ", account=" + account + "]";
	}
	
	

}

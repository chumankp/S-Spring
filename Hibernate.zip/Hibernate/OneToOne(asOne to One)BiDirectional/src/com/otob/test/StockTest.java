package com.otob.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otob.entity.Stock;
import com.otob.entity.StockDetails;
import com.otob.util.SessionFactoryRegistry;



public class StockTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		Stock stock = null;
		StockDetails stockdetails = null;
		boolean flag = false;
		try {
			factory = SessionFactoryRegistry.getSessionFactory();
			session = factory.getCurrentSession();
			transaction = session.beginTransaction();
			
			stock = new Stock();
			stock.setStockCode("tcs");
			stock.setStockName("TATA");
			stock.setStockDetails(stockdetails);
			session.save(stock);
			
			stockdetails = new StockDetails();
			stockdetails.setCompanyName("TCS INDIA");
			stockdetails.setCompanyDesc("Software");
			stockdetails.setListingDate(new Date());
			stockdetails.setRemark("GOOD");
			stockdetails.setStock(stock);
			session.save(stockdetails);
			
			
			
			flag = true;
		}finally {
			if(transaction != null) {
				if (flag) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
			}
		SessionFactoryRegistry.closeSessionFactory();
		}
	}

}

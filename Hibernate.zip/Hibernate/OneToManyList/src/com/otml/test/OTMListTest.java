package com.otml.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.otml.entities.Project;
import com.otml.entities.Rsources;
import com.otml.util.SessionFactoryRegistry;

public class OTMListTest {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		Transaction transaction = null;
		Project project = null;
		Rsources resource = null;
		Rsources resource1 =null;
		List<Rsources> list = null;
		boolean flag = false;
		try {
			factory = SessionFactoryRegistry.getSessionFactory();
			session = factory.openSession();
			transaction = session.beginTransaction();
			list = new ArrayList<Rsources>();
			resource = new Rsources();
			//resource.setResourcesNo(1);
			resource.setResourcesName("chuman");
			resource.setStartingDate(new Date());
			resource.setContactNo("123456789");
			resource.setEmailId("chuman@gmail.com");
			session.save(resource);
			resource1 =new Rsources();
			resource1.setResourcesName("Deep");
			resource1.setStartingDate(new Date());
			resource1.setContactNo("132546");
			resource1.setEmailId("chuma@gm.com");
			session.save(resource1);
			list.add(resource);
			list.add(resource1);
			project = new Project();
			project.setProjectName("Banking");
			project.setdProject("internate banking");
			project.setAssgingDate(new Date());
			project.setRsources(list);
			session.save(project);
			/*project = (Project) session.get(Project.class, 3);
			System.out.println(project);*/
			flag = true;
		}finally {
			if(transaction != null) {
				if (flag) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
			}
		}
		SessionFactoryRegistry.closeSessionFactory();
	}

}

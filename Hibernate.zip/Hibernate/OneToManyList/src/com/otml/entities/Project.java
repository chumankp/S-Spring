package com.otml.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Project implements Serializable {
	protected int projectNo;
	protected String projectName;
	protected Date assgingDate;
	protected String dProject;
	protected List<Rsources> rsources;
	public int getProjectNo() {
		return projectNo;
	}
	public void setProjectNo(int projectNo) {
		this.projectNo = projectNo;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public Date getAssgingDate() {
		return assgingDate;
	}
	public void setAssgingDate(Date assgingDate) {
		this.assgingDate = assgingDate;
	}
	public String getdProject() {
		return dProject;
	}
	public void setdProject(String dProject) {
		this.dProject = dProject;
	}
	public List<Rsources> getRsources() {
		return rsources;
	}
	public void setRsources(List<Rsources> rsources) {
		this.rsources = rsources;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((assgingDate == null) ? 0 : assgingDate.hashCode());
		result = prime * result + ((dProject == null) ? 0 : dProject.hashCode());
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + projectNo;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (assgingDate == null) {
			if (other.assgingDate != null)
				return false;
		} else if (!assgingDate.equals(other.assgingDate))
			return false;
		if (dProject == null) {
			if (other.dProject != null)
				return false;
		} else if (!dProject.equals(other.dProject))
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		if (projectNo != other.projectNo)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Project [projectNo=" + projectNo + ", projectName=" + projectName + ", assgingDate=" + assgingDate
				+ ", dProject=" + dProject + ", rsources=" + rsources + "]";
	}
	
}

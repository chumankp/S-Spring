package com.lg.proptest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.lg.entity.Address;
import com.lg.utlity.PropertiesSessionFactoryResgistry;

public class PropTest {

	public static void main(String[] args) {
	SessionFactory sessionfactory=null;
	Session session=null;
	sessionfactory = PropertiesSessionFactoryResgistry.getSessionFactory();
	session = sessionfactory.openSession();
	
	Address address = (Address) session.get(Address.class, 1014);
	System.out.println(address);

	}

}

package com.lg.programatic;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ProgramaticSessionFactoryRegistry {
	private static SessionFactory sessionFactory = null;
	static {
		Configuration conf=new Configuration();
		conf.addResource("com/lg/entity/Address.hbm.xml");
		conf.setProperty("hibernate.driver_class","com.mysql.jdbc.Driver");
		conf.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/automobiles");
		conf.setProperty("hibernate.connection.user", "root");
		conf.setProperty("hibernate.connection.password", "chuman");
		conf.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
		conf.setProperty("hibernate.show_sql", "true");
		sessionFactory=conf.buildSessionFactory();
	}
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public static void closeSessionFactory() {
		sessionFactory.close();
	}
}

package com.hbt.entity;

public class Advisor {
	protected int AdvisorNo;
	protected String firstName;
	protected String lastName;
	protected String qualification;
	protected int experince;
	protected int contactNo;
	protected String emailAddress;

	public int getAdvisorNo() {
		return AdvisorNo;
	}

	public void setAdvisorNo(int advisorNo) {
		AdvisorNo = advisorNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public int getExperince() {
		return experince;
	}

	public void setExperince(int experince) {
		this.experince = experince;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return "Advisor [AdvisorNo=" + AdvisorNo + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", qualification=" + qualification + ", experince=" + experince + ", contactNo=" + contactNo
				+ ", emailAddress=" + emailAddress + "]";
	}

}

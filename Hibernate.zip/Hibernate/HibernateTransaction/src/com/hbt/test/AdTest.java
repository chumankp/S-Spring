package com.hbt.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hbt.entity.Advisor;

public class AdTest {

	public static void main(String[] args) {
		boolean flag = false;
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionfactory = configuration.buildSessionFactory();
		Session session = sessionfactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			Advisor advisor = new Advisor();
			advisor.setAdvisorNo(7);
			advisor.setFirstName("deep");
			advisor.setLastName("mishra");
			advisor.setQualification("B.tech");
			advisor.setExperince(5);
			advisor.setContactNo(987654321);
			advisor.setEmailAddress("test@test.com");
			session.save(advisor);
			flag = true;
		} finally {
			if(session != null && transaction != null) {
				if(flag) {
					transaction.commit();
				}
				else {
					transaction.rollback();
				}
				session.close();
			}
			if(sessionfactory != null) {
				sessionfactory.close();
			}
		}

	}
}